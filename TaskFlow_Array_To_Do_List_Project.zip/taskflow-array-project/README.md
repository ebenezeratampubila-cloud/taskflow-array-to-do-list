# TaskFlow — To-Do List Application Using Arrays

## Project overview
TaskFlow is a browser-based to-do list for recording and managing everyday tasks. Its main task collection is a JavaScript array named `tasks`. Each array element is an object representing one task.

## Features
- Add a task, due date, priority and optional note
- Mark tasks as completed or pending
- Delete tasks
- Filter all, pending and completed tasks
- Display total, completed and remaining task counts
- Save task data in the browser using localStorage
- Responsive layout for phones and computers

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a modern web browser.
3. Add tasks and test the buttons. No installation is required.

## Array operations demonstrated
- `tasks.push(task)` adds a task.
- `tasks.findIndex(...)` searches for a task.
- `tasks[index].completed = ...` updates a task.
- `tasks.splice(index, 1)` deletes a task.
- `tasks.filter(...)` creates filtered views.
- `tasks.length` counts the tasks.

## Deploy with GitHub Pages
1. Sign in to GitHub and create a new public repository, e.g. `taskflow-array-project`.
2. Upload `index.html` and `README.md` (or upload the extracted project files).
3. Open the repository's **Settings → Pages**.
4. Under build/deployment, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for the deployment to finish. GitHub will show the published website URL in Pages settings.
7. Open the URL and test the app before submitting it.

## Important
The app's task list is held in a JavaScript array while it runs. Browser `localStorage` is used to restore that array after a refresh on the same browser/device. This is a front-end demonstration, not a shared multi-user database.
